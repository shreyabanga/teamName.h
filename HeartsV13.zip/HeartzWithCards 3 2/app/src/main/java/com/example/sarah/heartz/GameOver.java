package com.example.sarah.heartz;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import android.view.View;
import android.view.View.OnClickListener;

import android.widget.Button;
import android.widget.TextView;

public class GameOver extends AppCompatActivity implements OnClickListener {

    private TextView tvname0;
    private TextView tvname1;
    private TextView tvname2;
    private TextView tvname3;
    private TextView tvwinner;
    private TextView tvscore0;
    private TextView tvscore1;
    private TextView tvscore2;
    private TextView tvscore3;

    private Button b;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_over);

        tvname0 = findViewById(R.id.textView6);
        tvname1 = findViewById(R.id.textView5);
        tvname2 = findViewById(R.id.textView7);
        tvname3 = findViewById(R.id.textView8);
        tvscore0 = findViewById(R.id.textView2);
        tvscore1 = findViewById(R.id.textView1);
        tvscore2 = findViewById(R.id.textView3);
        tvscore3 = findViewById(R.id.textView4);

        tvwinner = findViewById(R.id.textVieww);

        b = findViewById(R.id.button);
        b.setOnClickListener(this);

        int winner = getWinner();
        int scores[] = getScores();

        tvwinner.setText(getName(winner));
        tvname0.setText(getName(0));
        tvname1.setText(getName(1));
        tvname2.setText(getName(2));
        tvname3.setText(getName(3));

        tvscore0.setText(Integer.toString(scores[0]));
        tvscore1.setText(Integer.toString(scores[1]));
        tvscore2.setText(Integer.toString(scores[2]));
        tvscore3.setText(Integer.toString(scores[3]));


    }

    public void onClick(View v) {
        if (v.getId() == R.id.button) {


            Intent restartIntent = getBaseContext().getPackageManager().getLaunchIntentForPackage(getBaseContext().getPackageName());
            restartIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

            startActivity(restartIntent);

        }
    }

    native public int getWinner();
    native public int[] getScores();
    native public String getName(int player);

}
