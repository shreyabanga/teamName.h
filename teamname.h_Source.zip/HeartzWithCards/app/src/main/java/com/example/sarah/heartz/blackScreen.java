package com.example.sarah.heartz;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;

public class blackScreen extends AppCompatActivity implements OnClickListener {

    private TextView tv;
    private View v;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //On create, loads in the layout and text field and sets one text field to display the name
        //of the current player

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_black_screen);

        tv = findViewById(R.id.textView11);
        v=findViewById(R.id.view3);

        v.setOnClickListener(this);

        //Displays the name of the current player
        int current = getCurrentPlayer();
        tv.setText(getName(current));

    }

    public void onClick(View v) {
        if (v.getId() == R.id.view3) {
            //If the user clicks anywhere on the screen, the screen moves to the current player's screen
            int current = getCurrentPlayer();
            switch(current) {
                case 0:
                    Intent resultActivity = new Intent(blackScreen.this, player0.class);
                    startActivity(resultActivity);
                    break;
                case 1:
                    Intent resultActivity1 = new Intent(blackScreen.this, player1.class);
                    startActivity(resultActivity1);
                    break;
                case 2:
                    Intent resultActivity2 = new Intent(blackScreen.this, player2.class);
                    startActivity(resultActivity2);
                    break;
                default:
                    Intent resultActivity3 = new Intent(blackScreen.this, player3.class);
                    startActivity(resultActivity3);
                    break;

            }

        }
    }

    public native int getCurrentPlayer();
    public native String getName(int val);

}
