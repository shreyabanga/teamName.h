package com.example.sarah.heartz;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.view.View;
import android.view.View.OnClickListener;

public class Scores extends AppCompatActivity implements OnClickListener {

    private View v;
    private TextView tvname0;
    private TextView tvname1;
    private TextView tvname2;
    private TextView tvname3;
    private TextView tvscore0;
    private TextView tvscore1;
    private TextView tvscore2;
    private TextView tvscore3;

    private Button b;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scores);

        tvname0 = findViewById(R.id.textView6);
        tvname1 = findViewById(R.id.textView8);
        tvname2 = findViewById(R.id.textView5);
        tvname3 = findViewById(R.id.textView7);
        tvscore0 = findViewById(R.id.textView2);
        tvscore1 = findViewById(R.id.textView3);
        tvscore2 = findViewById(R.id.textView1);
        tvscore3 = findViewById(R.id.textView4);

        b = findViewById(R.id.button14);
        b.setOnClickListener(this);

        int scores[] = getScores();

        tvname0.setText(getName(0));
        tvname1.setText(getName(1));
        tvname2.setText(getName(2));
        tvname3.setText(getName(3));

        tvscore0.setText(Integer.toString(scores[0]));
        tvscore1.setText(Integer.toString(scores[1]));
        tvscore2.setText(Integer.toString(scores[2]));
        tvscore3.setText(Integer.toString(scores[3]));
    }

    public void onClick(View v) {
        if (v.getId() == R.id.button14) {
            int current = getCurrentPlayer();
            switch (current) {
                case 0:
                    Intent returns0 = new Intent(Scores.this, player0.class);
                    startActivity(returns0);
                    break;
                case 1:
                    Intent returns1 = new Intent(Scores.this, player1.class);
                    startActivity(returns1);
                    break;
                case 2:
                    Intent returns2 = new Intent(Scores.this, player2.class);
                    startActivity(returns2);
                    break;
                default:
                    Intent returns3 = new Intent(Scores.this, player3.class);
                    startActivity(returns3);
                    break;
            }

        }
    }
    native public int[] getScores();
    native public String getName(int player);
    native public int getCurrentPlayer();
}
