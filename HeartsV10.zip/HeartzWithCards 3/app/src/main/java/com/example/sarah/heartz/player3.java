package com.example.sarah.heartz;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import org.w3c.dom.Text;

public class player3 extends AppCompatActivity {

    private View v;
    private TextView tv;
    static int counter=0;
    private Button b1;
    private Button b2;
    private Button b3;
    private Button b4;
    private Button b5;
    private Button b6;
    private Button b7;
    private Button b8;
    private Button b9;
    private Button b10;
    private Button b11;
    private Button b12;
    private Button b13;
    private ImageView iV1;
    private ImageView iV2;
    private ImageView iV3;
    private ImageView iV4;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player1);

        b1=findViewById(R.id.button);
        b2=findViewById(R.id.button2);
        b3=findViewById(R.id.button3);
        b4=findViewById(R.id.button4);
        b5=findViewById(R.id.button5);
        b6=findViewById(R.id.button6);
        b7=findViewById(R.id.button7);
        b8=findViewById(R.id.button8);
        b9=findViewById(R.id.button9);
        b10=findViewById(R.id.button10);
        b11=findViewById(R.id.button11);
        b12=findViewById(R.id.button12);
        b13=findViewById(R.id.button13);

        iV1=findViewById(R.id.imageView1);
        iV2=findViewById(R.id.imageView2);
        iV3=findViewById(R.id.imageView3);
        iV4=findViewById(R.id.imageView4);

        tv= findViewById(R.id.textView);




    }

    @Override
    protected void onResume(){
        super.onResume();

        String name = getName(3);
        tv.setText(name);

        int[] playedDeck = getPlayedDeck();
        tv.setText(Integer.toString(playedDeck.length));
        int sizeDeck = playedDeck.length;

        switch (sizeDeck) {
            case 0:
                iV1.setVisibility(View.INVISIBLE);
                iV2.setVisibility(View.INVISIBLE);
                iV3.setVisibility(View.INVISIBLE);
                iV4.setVisibility(View.INVISIBLE);
                break;
            case 1:
                assignDeckImages(playedDeck[0],iV2);
                iV1.setVisibility(View.INVISIBLE);
                iV3.setVisibility(View.INVISIBLE);
                iV4.setVisibility(View.INVISIBLE);
                break;
            case 2:
                iV1.setVisibility(View.INVISIBLE);
                assignDeckImages(playedDeck[0],iV2);
                iV3.setVisibility(View.INVISIBLE);
                assignDeckImages(playedDeck[1],iV4);
                break;
            default:
                iV1.setVisibility(View.INVISIBLE);
                assignDeckImages(playedDeck[0],iV2);
                assignDeckImages(playedDeck[2],iV3);
                assignDeckImages(playedDeck[1],iV4);
                break;
        }

        int hand[] = getHand(3);
        int size = hand.length;
        switch (size) {
            case 13:
                assignImages(hand[12],b1);
                assignImages(hand[11],b2);
                assignImages(hand[10],b3);
                assignImages(hand[9],b4);
                assignImages(hand[8],b5);
                assignImages(hand[7],b6);
                assignImages(hand[6],b7);
                assignImages(hand[5],b8);
                assignImages(hand[4],b9);
                assignImages(hand[3],b10);
                assignImages(hand[2],b11);
                assignImages(hand[1],b12);
                assignImages(hand[0],b13);
                break;
            case 12:
                b1.setVisibility(View.INVISIBLE);
                assignImages(hand[11],b2);
                assignImages(hand[10],b3);
                assignImages(hand[9],b4);
                assignImages(hand[8],b5);
                assignImages(hand[7],b6);
                assignImages(hand[6],b7);
                assignImages(hand[5],b8);
                assignImages(hand[4],b9);
                assignImages(hand[3],b10);
                assignImages(hand[2],b11);
                assignImages(hand[1],b12);
                assignImages(hand[0],b13);
                break;
            case 11:
                b1.setVisibility(View.INVISIBLE);
                b2.setVisibility(View.INVISIBLE);
                assignImages(hand[10],b3);
                assignImages(hand[9],b4);
                assignImages(hand[8],b5);
                assignImages(hand[7],b6);
                assignImages(hand[6],b7);
                assignImages(hand[5],b8);
                assignImages(hand[4],b9);
                assignImages(hand[3],b10);
                assignImages(hand[2],b11);
                assignImages(hand[1],b12);
                assignImages(hand[0],b13);
                break;
            case 10:
                b1.setVisibility(View.INVISIBLE);
                b2.setVisibility(View.INVISIBLE);
                b3.setVisibility(View.INVISIBLE);
                assignImages(hand[9],b4);
                assignImages(hand[8],b5);
                assignImages(hand[7],b6);
                assignImages(hand[6],b7);
                assignImages(hand[5],b8);
                assignImages(hand[4],b9);
                assignImages(hand[3],b10);
                assignImages(hand[2],b11);
                assignImages(hand[1],b12);
                assignImages(hand[0],b13);
                break;
            case 9:
                b1.setVisibility(View.INVISIBLE);
                b2.setVisibility(View.INVISIBLE);
                b3.setVisibility(View.INVISIBLE);
                b4.setVisibility(View.INVISIBLE);
                assignImages(hand[8],b5);
                assignImages(hand[7],b6);
                assignImages(hand[6],b7);
                assignImages(hand[5],b8);
                assignImages(hand[4],b9);
                assignImages(hand[3],b10);
                assignImages(hand[2],b11);
                assignImages(hand[1],b12);
                assignImages(hand[0],b13);
                break;
            case 8:
                b1.setVisibility(View.INVISIBLE);
                b2.setVisibility(View.INVISIBLE);
                b3.setVisibility(View.INVISIBLE);
                b4.setVisibility(View.INVISIBLE);
                b5.setVisibility(View.INVISIBLE);
                assignImages(hand[7],b6);
                assignImages(hand[6],b7);
                assignImages(hand[5],b8);
                assignImages(hand[4],b9);
                assignImages(hand[3],b10);
                assignImages(hand[2],b11);
                assignImages(hand[1],b12);
                assignImages(hand[0],b13);
                break;
            case 7:
                b1.setVisibility(View.INVISIBLE);
                b2.setVisibility(View.INVISIBLE);
                b3.setVisibility(View.INVISIBLE);
                b4.setVisibility(View.INVISIBLE);
                b5.setVisibility(View.INVISIBLE);
                b6.setVisibility(View.INVISIBLE);
                assignImages(hand[6],b7);
                assignImages(hand[5],b8);
                assignImages(hand[4],b9);
                assignImages(hand[3],b10);
                assignImages(hand[2],b11);
                assignImages(hand[1],b12);
                assignImages(hand[0],b13);
                break;
            case 6:
                b1.setVisibility(View.INVISIBLE);
                b2.setVisibility(View.INVISIBLE);
                b3.setVisibility(View.INVISIBLE);
                b4.setVisibility(View.INVISIBLE);
                b5.setVisibility(View.INVISIBLE);
                b6.setVisibility(View.INVISIBLE);
                b7.setVisibility(View.INVISIBLE);
                assignImages(hand[5],b8);
                assignImages(hand[4],b9);
                assignImages(hand[3],b10);
                assignImages(hand[2],b11);
                assignImages(hand[1],b12);
                assignImages(hand[0],b13);
                break;
            case 5:
                b1.setVisibility(View.INVISIBLE);
                b2.setVisibility(View.INVISIBLE);
                b3.setVisibility(View.INVISIBLE);
                b4.setVisibility(View.INVISIBLE);
                b5.setVisibility(View.INVISIBLE);
                b6.setVisibility(View.INVISIBLE);
                b7.setVisibility(View.INVISIBLE);
                b8.setVisibility(View.INVISIBLE);
                assignImages(hand[4],b9);
                assignImages(hand[3],b10);
                assignImages(hand[2],b11);
                assignImages(hand[1],b12);
                assignImages(hand[0],b13);
                break;
            case 4:
                b1.setVisibility(View.INVISIBLE);
                b2.setVisibility(View.INVISIBLE);
                b3.setVisibility(View.INVISIBLE);
                b4.setVisibility(View.INVISIBLE);
                b5.setVisibility(View.INVISIBLE);
                b6.setVisibility(View.INVISIBLE);
                b7.setVisibility(View.INVISIBLE);
                b8.setVisibility(View.INVISIBLE);
                b9.setVisibility(View.INVISIBLE);
                assignImages(hand[3],b10);
                assignImages(hand[2],b11);
                assignImages(hand[1],b12);
                assignImages(hand[0],b13);
                break;
            case 3:
                b1.setVisibility(View.INVISIBLE);
                b2.setVisibility(View.INVISIBLE);
                b3.setVisibility(View.INVISIBLE);
                b4.setVisibility(View.INVISIBLE);
                b5.setVisibility(View.INVISIBLE);
                b6.setVisibility(View.INVISIBLE);
                b7.setVisibility(View.INVISIBLE);
                b8.setVisibility(View.INVISIBLE);
                b9.setVisibility(View.INVISIBLE);
                b10.setVisibility(View.INVISIBLE);
                assignImages(hand[2],b11);
                assignImages(hand[1],b12);
                assignImages(hand[0],b13);
                break;
            case 2:
                b1.setVisibility(View.INVISIBLE);
                b2.setVisibility(View.INVISIBLE);
                b3.setVisibility(View.INVISIBLE);
                b4.setVisibility(View.INVISIBLE);
                b5.setVisibility(View.INVISIBLE);
                b6.setVisibility(View.INVISIBLE);
                b7.setVisibility(View.INVISIBLE);
                b8.setVisibility(View.INVISIBLE);
                b9.setVisibility(View.INVISIBLE);
                b10.setVisibility(View.INVISIBLE);
                b11.setVisibility(View.INVISIBLE);
                assignImages(hand[1],b12);
                assignImages(hand[0],b13);
                break;
            default:
                b1.setVisibility(View.INVISIBLE);
                b2.setVisibility(View.INVISIBLE);
                b3.setVisibility(View.INVISIBLE);
                b4.setVisibility(View.INVISIBLE);
                b5.setVisibility(View.INVISIBLE);
                b6.setVisibility(View.INVISIBLE);
                b7.setVisibility(View.INVISIBLE);
                b8.setVisibility(View.INVISIBLE);
                b9.setVisibility(View.INVISIBLE);
                b10.setVisibility(View.INVISIBLE);
                b11.setVisibility(View.INVISIBLE);
                b12.setVisibility(View.INVISIBLE);
                assignImages(hand[0],b13);
                break;
        }
    }

    public void onClick(View v) {
        boolean result;
        if (v.getId() == R.id.button) {
            int hand[] = getHand(3);
            result = cardPlayed(hand[12]);
            if (!result) {
                {Snackbar.make(v, "Invalid Play!", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();}
            }
            else {
                if (!isEndOfTrick()) {
                    Intent resultActivity = new Intent(player3.this, player0.class);
                    startActivity(resultActivity);
                }
                else {
                    endOfTrick();
                    if (!isEndOfRound()) {
                        int starter = getStarter();
                        switch (starter) {
                            case 1:
                                Intent resultActivity1 = new Intent(player3.this, player1.class);
                                startActivity(resultActivity1);
                                break;
                            case 2:
                                Intent resultActivity2 = new Intent(player3.this, player2.class);
                                startActivity(resultActivity2);
                                break;
                            case 3:
                                Intent resultActivity3 = new Intent(player3.this, player3.class);
                                startActivity(resultActivity3);
                                break;
                            default:
                                Intent resultActivity0 = new Intent(player3.this, player0.class);
                                startActivity(resultActivity0);
                                break;
                        }
                    }
                    else {
                        endOfRound();
                        if (!isGameOver()) {
                            shuffleDeal();
                            int starter = getStarter();
                            switch (starter) {
                                case 1:
                                    Intent resultActivity1 = new Intent(player3.this, player1.class);
                                    startActivity(resultActivity1);
                                    break;
                                case 2:
                                    Intent resultActivity2 = new Intent(player3.this, player2.class);
                                    startActivity(resultActivity2);
                                    break;
                                case 3:
                                    Intent resultActivity3 = new Intent(player3.this, player3.class);
                                    startActivity(resultActivity3);
                                    break;
                                default:
                                    Intent resultActivity0 = new Intent(player3.this, player0.class);
                                    startActivity(resultActivity0);
                                    break;
                            }
                        }
                        else {
                            Intent resultActivity = new Intent(player3.this, GameOver.class);
                            startActivity(resultActivity);
                        }
                    }
                }
            }

        }
        if (v.getId() == R.id.button2) {
            int hand[] = getHand(3);
            result = cardPlayed(hand[11]);
            if (!result) {
                {Snackbar.make(v, "Invalid Play!", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();}
            }
            else {
                if (!isEndOfTrick()) {
                    Intent resultActivity = new Intent(player3.this, player0.class);
                    startActivity(resultActivity);
                }
                else {
                    endOfTrick();
                    if (!isEndOfRound()) {
                        int starter = getStarter();
                        switch (starter) {
                            case 1:
                                Intent resultActivity1 = new Intent(player3.this, player1.class);
                                startActivity(resultActivity1);
                                break;
                            case 2:
                                Intent resultActivity2 = new Intent(player3.this, player2.class);
                                startActivity(resultActivity2);
                                break;
                            case 3:
                                Intent resultActivity3 = new Intent(player3.this, player3.class);
                                startActivity(resultActivity3);
                                break;
                            default:
                                Intent resultActivity0 = new Intent(player3.this, player0.class);
                                startActivity(resultActivity0);
                                break;
                        }
                    }
                    else {
                        endOfRound();
                        if (!isGameOver()) {
                            shuffleDeal();
                            int starter = getStarter();
                            switch (starter) {
                                case 1:
                                    Intent resultActivity1 = new Intent(player3.this, player1.class);
                                    startActivity(resultActivity1);
                                    break;
                                case 2:
                                    Intent resultActivity2 = new Intent(player3.this, player2.class);
                                    startActivity(resultActivity2);
                                    break;
                                case 3:
                                    Intent resultActivity3 = new Intent(player3.this, player3.class);
                                    startActivity(resultActivity3);
                                    break;
                                default:
                                    Intent resultActivity0 = new Intent(player3.this, player0.class);
                                    startActivity(resultActivity0);
                                    break;
                            }
                        }
                        else {
                            Intent resultActivity = new Intent(player3.this, GameOver.class);
                            startActivity(resultActivity);
                        }
                    }
                }
            }

        }
        if (v.getId() == R.id.button3) {
            int hand[] = getHand(3);
            result = cardPlayed(hand[10]);
            if (!result) {
                {Snackbar.make(v, "Invalid Play!", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();}
            }
            else {
                if (!isEndOfTrick()) {
                    Intent resultActivity = new Intent(player3.this, player0.class);
                    startActivity(resultActivity);
                }
                else {
                    endOfTrick();
                    if (!isEndOfRound()) {
                        int starter = getStarter();
                        switch (starter) {
                            case 1:
                                Intent resultActivity1 = new Intent(player3.this, player1.class);
                                startActivity(resultActivity1);
                                break;
                            case 2:
                                Intent resultActivity2 = new Intent(player3.this, player2.class);
                                startActivity(resultActivity2);
                                break;
                            case 3:
                                Intent resultActivity3 = new Intent(player3.this, player3.class);
                                startActivity(resultActivity3);
                                break;
                            default:
                                Intent resultActivity0 = new Intent(player3.this, player0.class);
                                startActivity(resultActivity0);
                                break;
                        }
                    }
                    else {
                        endOfRound();
                        if (!isGameOver()) {
                            shuffleDeal();
                            int starter = getStarter();
                            switch (starter) {
                                case 1:
                                    Intent resultActivity1 = new Intent(player3.this, player1.class);
                                    startActivity(resultActivity1);
                                    break;
                                case 2:
                                    Intent resultActivity2 = new Intent(player3.this, player2.class);
                                    startActivity(resultActivity2);
                                    break;
                                case 3:
                                    Intent resultActivity3 = new Intent(player3.this, player3.class);
                                    startActivity(resultActivity3);
                                    break;
                                default:
                                    Intent resultActivity0 = new Intent(player3.this, player0.class);
                                    startActivity(resultActivity0);
                                    break;
                            }
                        }
                        else {
                            Intent resultActivity = new Intent(player3.this, GameOver.class);
                            startActivity(resultActivity);
                        }
                    }
                }
            }

        }
        if (v.getId() == R.id.button4) {
            int hand[] = getHand(3);
            result = cardPlayed(hand[9]);
            if (!result) {
                {Snackbar.make(v, "Invalid Play!", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();}
            }
            else {
                if (!isEndOfTrick()) {
                    Intent resultActivity = new Intent(player3.this, player0.class);
                    startActivity(resultActivity);
                }
                else {
                    endOfTrick();
                    if (!isEndOfRound()) {
                        int starter = getStarter();
                        switch (starter) {
                            case 1:
                                Intent resultActivity1 = new Intent(player3.this, player1.class);
                                startActivity(resultActivity1);
                                break;
                            case 2:
                                Intent resultActivity2 = new Intent(player3.this, player2.class);
                                startActivity(resultActivity2);
                                break;
                            case 3:
                                Intent resultActivity3 = new Intent(player3.this, player3.class);
                                startActivity(resultActivity3);
                                break;
                            default:
                                Intent resultActivity0 = new Intent(player3.this, player0.class);
                                startActivity(resultActivity0);
                                break;
                        }
                    }
                    else {
                        endOfRound();
                        if (!isGameOver()) {
                            shuffleDeal();
                            int starter = getStarter();
                            switch (starter) {
                                case 1:
                                    Intent resultActivity1 = new Intent(player3.this, player1.class);
                                    startActivity(resultActivity1);
                                    break;
                                case 2:
                                    Intent resultActivity2 = new Intent(player3.this, player2.class);
                                    startActivity(resultActivity2);
                                    break;
                                case 3:
                                    Intent resultActivity3 = new Intent(player3.this, player3.class);
                                    startActivity(resultActivity3);
                                    break;
                                default:
                                    Intent resultActivity0 = new Intent(player3.this, player0.class);
                                    startActivity(resultActivity0);
                                    break;
                            }
                        }
                        else {
                            Intent resultActivity = new Intent(player3.this, GameOver.class);
                            startActivity(resultActivity);
                        }
                    }
                }
            }

        }
        if (v.getId() == R.id.button5) {
            int hand[] = getHand(3);
            result = cardPlayed(hand[8]);
            if (!result) {
                {Snackbar.make(v, "Invalid Play!", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();}
            }
            else {
                if (!isEndOfTrick()) {
                    Intent resultActivity = new Intent(player3.this, player0.class);
                    startActivity(resultActivity);
                }
                else {
                    endOfTrick();
                    if (!isEndOfRound()) {
                        int starter = getStarter();
                        switch (starter) {
                            case 1:
                                Intent resultActivity1 = new Intent(player3.this, player1.class);
                                startActivity(resultActivity1);
                                break;
                            case 2:
                                Intent resultActivity2 = new Intent(player3.this, player2.class);
                                startActivity(resultActivity2);
                                break;
                            case 3:
                                Intent resultActivity3 = new Intent(player3.this, player3.class);
                                startActivity(resultActivity3);
                                break;
                            default:
                                Intent resultActivity0 = new Intent(player3.this, player0.class);
                                startActivity(resultActivity0);
                                break;
                        }
                    }
                    else {
                        endOfRound();
                        if (!isGameOver()) {
                            shuffleDeal();
                            int starter = getStarter();
                            switch (starter) {
                                case 1:
                                    Intent resultActivity1 = new Intent(player3.this, player1.class);
                                    startActivity(resultActivity1);
                                    break;
                                case 2:
                                    Intent resultActivity2 = new Intent(player3.this, player2.class);
                                    startActivity(resultActivity2);
                                    break;
                                case 3:
                                    Intent resultActivity3 = new Intent(player3.this, player3.class);
                                    startActivity(resultActivity3);
                                    break;
                                default:
                                    Intent resultActivity0 = new Intent(player3.this, player0.class);
                                    startActivity(resultActivity0);
                                    break;
                            }
                        }
                        else {
                            Intent resultActivity = new Intent(player3.this, GameOver.class);
                            startActivity(resultActivity);
                        }
                    }
                }
            }

        }
        if (v.getId() == R.id.button6) {
            int hand[] = getHand(3);
            result = cardPlayed(hand[7]);
            if (!result) {
                {Snackbar.make(v, "Invalid Play!", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();}
            }
            else {
                if (!isEndOfTrick()) {
                    Intent resultActivity = new Intent(player3.this, player0.class);
                    startActivity(resultActivity);
                }
                else {
                    endOfTrick();
                    if (!isEndOfRound()) {
                        int starter = getStarter();
                        switch (starter) {
                            case 1:
                                Intent resultActivity1 = new Intent(player3.this, player1.class);
                                startActivity(resultActivity1);
                                break;
                            case 2:
                                Intent resultActivity2 = new Intent(player3.this, player2.class);
                                startActivity(resultActivity2);
                                break;
                            case 3:
                                Intent resultActivity3 = new Intent(player3.this, player3.class);
                                startActivity(resultActivity3);
                                break;
                            default:
                                Intent resultActivity0 = new Intent(player3.this, player0.class);
                                startActivity(resultActivity0);
                                break;
                        }
                    }
                    else {
                        endOfRound();
                        if (!isGameOver()) {
                            shuffleDeal();
                            int starter = getStarter();
                            switch (starter) {
                                case 1:
                                    Intent resultActivity1 = new Intent(player3.this, player1.class);
                                    startActivity(resultActivity1);
                                    break;
                                case 2:
                                    Intent resultActivity2 = new Intent(player3.this, player2.class);
                                    startActivity(resultActivity2);
                                    break;
                                case 3:
                                    Intent resultActivity3 = new Intent(player3.this, player3.class);
                                    startActivity(resultActivity3);
                                    break;
                                default:
                                    Intent resultActivity0 = new Intent(player3.this, player0.class);
                                    startActivity(resultActivity0);
                                    break;
                            }
                        }
                        else {
                            Intent resultActivity = new Intent(player3.this, GameOver.class);
                            startActivity(resultActivity);
                        }
                    }
                }
            }

        }
        if (v.getId() == R.id.button7) {
            int hand[] = getHand(3);
            result = cardPlayed(hand[6]);
            if (!result) {
                {Snackbar.make(v, "Invalid Play!", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();}
            }
            else {
                if (!isEndOfTrick()) {
                    Intent resultActivity = new Intent(player3.this, player0.class);
                    startActivity(resultActivity);
                }
                else {
                    endOfTrick();
                    if (!isEndOfRound()) {
                        int starter = getStarter();
                        switch (starter) {
                            case 1:
                                Intent resultActivity1 = new Intent(player3.this, player1.class);
                                startActivity(resultActivity1);
                                break;
                            case 2:
                                Intent resultActivity2 = new Intent(player3.this, player2.class);
                                startActivity(resultActivity2);
                                break;
                            case 3:
                                Intent resultActivity3 = new Intent(player3.this, player3.class);
                                startActivity(resultActivity3);
                                break;
                            default:
                                Intent resultActivity0 = new Intent(player3.this, player0.class);
                                startActivity(resultActivity0);
                                break;
                        }
                    }
                    else {
                        endOfRound();
                        if (!isGameOver()) {
                            shuffleDeal();
                            int starter = getStarter();
                            switch (starter) {
                                case 1:
                                    Intent resultActivity1 = new Intent(player3.this, player1.class);
                                    startActivity(resultActivity1);
                                    break;
                                case 2:
                                    Intent resultActivity2 = new Intent(player3.this, player2.class);
                                    startActivity(resultActivity2);
                                    break;
                                case 3:
                                    Intent resultActivity3 = new Intent(player3.this, player3.class);
                                    startActivity(resultActivity3);
                                    break;
                                default:
                                    Intent resultActivity0 = new Intent(player3.this, player0.class);
                                    startActivity(resultActivity0);
                                    break;
                            }
                        }
                        else {
                            Intent resultActivity = new Intent(player3.this, GameOver.class);
                            startActivity(resultActivity);
                        }
                    }
                }
            }

        }
        if (v.getId() == R.id.button8) {
            int hand[] = getHand(3);
            result = cardPlayed(hand[5]);
            if (!result) {
                {Snackbar.make(v, "Invalid Play!", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();}
            }
            else {
                if (!isEndOfTrick()) {
                    Intent resultActivity = new Intent(player3.this, player0.class);
                    startActivity(resultActivity);
                }
                else {
                    endOfTrick();
                    if (!isEndOfRound()) {
                        int starter = getStarter();
                        switch (starter) {
                            case 1:
                                Intent resultActivity1 = new Intent(player3.this, player1.class);
                                startActivity(resultActivity1);
                                break;
                            case 2:
                                Intent resultActivity2 = new Intent(player3.this, player2.class);
                                startActivity(resultActivity2);
                                break;
                            case 3:
                                Intent resultActivity3 = new Intent(player3.this, player3.class);
                                startActivity(resultActivity3);
                                break;
                            default:
                                Intent resultActivity0 = new Intent(player3.this, player0.class);
                                startActivity(resultActivity0);
                                break;
                        }
                    }
                    else {
                        endOfRound();
                        if (!isGameOver()) {
                            shuffleDeal();
                            int starter = getStarter();
                            switch (starter) {
                                case 1:
                                    Intent resultActivity1 = new Intent(player3.this, player1.class);
                                    startActivity(resultActivity1);
                                    break;
                                case 2:
                                    Intent resultActivity2 = new Intent(player3.this, player2.class);
                                    startActivity(resultActivity2);
                                    break;
                                case 3:
                                    Intent resultActivity3 = new Intent(player3.this, player3.class);
                                    startActivity(resultActivity3);
                                    break;
                                default:
                                    Intent resultActivity0 = new Intent(player3.this, player0.class);
                                    startActivity(resultActivity0);
                                    break;
                            }
                        }
                        else {
                            Intent resultActivity = new Intent(player3.this, GameOver.class);
                            startActivity(resultActivity);
                        }
                    }
                }
            }

        }
        if (v.getId() == R.id.button9) {
            int hand[] = getHand(3);
            result = cardPlayed(hand[4]);
            if (!result) {
                {Snackbar.make(v, "Invalid Play!", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();}
            }
            else {
                if (!isEndOfTrick()) {
                    Intent resultActivity = new Intent(player3.this, player0.class);
                    startActivity(resultActivity);
                }
                else {
                    endOfTrick();
                    if (!isEndOfRound()) {
                        int starter = getStarter();
                        switch (starter) {
                            case 1:
                                Intent resultActivity1 = new Intent(player3.this, player1.class);
                                startActivity(resultActivity1);
                                break;
                            case 2:
                                Intent resultActivity2 = new Intent(player3.this, player2.class);
                                startActivity(resultActivity2);
                                break;
                            case 3:
                                Intent resultActivity3 = new Intent(player3.this, player3.class);
                                startActivity(resultActivity3);
                                break;
                            default:
                                Intent resultActivity0 = new Intent(player3.this, player0.class);
                                startActivity(resultActivity0);
                                break;
                        }
                    }
                    else {
                        endOfRound();
                        if (!isGameOver()) {
                            shuffleDeal();
                            int starter = getStarter();
                            switch (starter) {
                                case 1:
                                    Intent resultActivity1 = new Intent(player3.this, player1.class);
                                    startActivity(resultActivity1);
                                    break;
                                case 2:
                                    Intent resultActivity2 = new Intent(player3.this, player2.class);
                                    startActivity(resultActivity2);
                                    break;
                                case 3:
                                    Intent resultActivity3 = new Intent(player3.this, player3.class);
                                    startActivity(resultActivity3);
                                    break;
                                default:
                                    Intent resultActivity0 = new Intent(player3.this, player0.class);
                                    startActivity(resultActivity0);
                                    break;
                            }
                        }
                        else {
                            Intent resultActivity = new Intent(player3.this, GameOver.class);
                            startActivity(resultActivity);
                        }
                    }
                }
            }

        }
        if (v.getId() == R.id.button10) {
            int hand[] = getHand(3);
            result = cardPlayed(hand[3]);
            if (!result) {
                {Snackbar.make(v, "Invalid Play!", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();}
            }
            else {
                if (!isEndOfTrick()) {
                    Intent resultActivity = new Intent(player3.this, player0.class);
                    startActivity(resultActivity);
                }
                else {
                    endOfTrick();
                    if (!isEndOfRound()) {
                        int starter = getStarter();
                        switch (starter) {
                            case 1:
                                Intent resultActivity1 = new Intent(player3.this, player1.class);
                                startActivity(resultActivity1);
                                break;
                            case 2:
                                Intent resultActivity2 = new Intent(player3.this, player2.class);
                                startActivity(resultActivity2);
                                break;
                            case 3:
                                Intent resultActivity3 = new Intent(player3.this, player3.class);
                                startActivity(resultActivity3);
                                break;
                            default:
                                Intent resultActivity0 = new Intent(player3.this, player0.class);
                                startActivity(resultActivity0);
                                break;
                        }
                    }
                    else {
                        endOfRound();
                        if (!isGameOver()) {
                            shuffleDeal();
                            int starter = getStarter();
                            switch (starter) {
                                case 1:
                                    Intent resultActivity1 = new Intent(player3.this, player1.class);
                                    startActivity(resultActivity1);
                                    break;
                                case 2:
                                    Intent resultActivity2 = new Intent(player3.this, player2.class);
                                    startActivity(resultActivity2);
                                    break;
                                case 3:
                                    Intent resultActivity3 = new Intent(player3.this, player3.class);
                                    startActivity(resultActivity3);
                                    break;
                                default:
                                    Intent resultActivity0 = new Intent(player3.this, player0.class);
                                    startActivity(resultActivity0);
                                    break;
                            }
                        }
                        else {
                            Intent resultActivity = new Intent(player3.this, GameOver.class);
                            startActivity(resultActivity);
                        }
                    }
                }
            }

        }
        if (v.getId() == R.id.button11) {
            int hand[] = getHand(3);
            result = cardPlayed(hand[2]);
            if (!result) {
                {Snackbar.make(v, "Invalid Play!", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();}
            }
            else {
                if (!isEndOfTrick()) {
                    Intent resultActivity = new Intent(player3.this, player0.class);
                    startActivity(resultActivity);
                }
                else {
                    endOfTrick();
                    if (!isEndOfRound()) {
                        int starter = getStarter();
                        switch (starter) {
                            case 1:
                                Intent resultActivity1 = new Intent(player3.this, player1.class);
                                startActivity(resultActivity1);
                                break;
                            case 2:
                                Intent resultActivity2 = new Intent(player3.this, player2.class);
                                startActivity(resultActivity2);
                                break;
                            case 3:
                                Intent resultActivity3 = new Intent(player3.this, player3.class);
                                startActivity(resultActivity3);
                                break;
                            default:
                                Intent resultActivity0 = new Intent(player3.this, player0.class);
                                startActivity(resultActivity0);
                                break;
                        }
                    }
                    else {
                        endOfRound();
                        if (!isGameOver()) {
                            shuffleDeal();
                            int starter = getStarter();
                            switch (starter) {
                                case 1:
                                    Intent resultActivity1 = new Intent(player3.this, player1.class);
                                    startActivity(resultActivity1);
                                    break;
                                case 2:
                                    Intent resultActivity2 = new Intent(player3.this, player2.class);
                                    startActivity(resultActivity2);
                                    break;
                                case 3:
                                    Intent resultActivity3 = new Intent(player3.this, player3.class);
                                    startActivity(resultActivity3);
                                    break;
                                default:
                                    Intent resultActivity0 = new Intent(player3.this, player0.class);
                                    startActivity(resultActivity0);
                                    break;
                            }
                        }
                        else {
                            Intent resultActivity = new Intent(player3.this, GameOver.class);
                            startActivity(resultActivity);
                        }
                    }
                }
            }

        }
        if (v.getId() == R.id.button12) {
            int hand[] = getHand(3);
            result = cardPlayed(hand[1]);
            if (!result) {
                {Snackbar.make(v, "Invalid Play!", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();}
            }
            else {
                if (!isEndOfTrick()) {
                    Intent resultActivity = new Intent(player3.this, player0.class);
                    startActivity(resultActivity);
                }
                else {
                    endOfTrick();
                    if (!isEndOfRound()) {
                        int starter = getStarter();
                        switch (starter) {
                            case 1:
                                Intent resultActivity1 = new Intent(player3.this, player1.class);
                                startActivity(resultActivity1);
                                break;
                            case 2:
                                Intent resultActivity2 = new Intent(player3.this, player2.class);
                                startActivity(resultActivity2);
                                break;
                            case 3:
                                Intent resultActivity3 = new Intent(player3.this, player3.class);
                                startActivity(resultActivity3);
                                break;
                            default:
                                Intent resultActivity0 = new Intent(player3.this, player0.class);
                                startActivity(resultActivity0);
                                break;
                        }
                    }
                    else {
                        endOfRound();
                        if (!isGameOver()) {
                            shuffleDeal();
                            int starter = getStarter();
                            switch (starter) {
                                case 1:
                                    Intent resultActivity1 = new Intent(player3.this, player1.class);
                                    startActivity(resultActivity1);
                                    break;
                                case 2:
                                    Intent resultActivity2 = new Intent(player3.this, player2.class);
                                    startActivity(resultActivity2);
                                    break;
                                case 3:
                                    Intent resultActivity3 = new Intent(player3.this, player3.class);
                                    startActivity(resultActivity3);
                                    break;
                                default:
                                    Intent resultActivity0 = new Intent(player3.this, player0.class);
                                    startActivity(resultActivity0);
                                    break;
                            }
                        }
                        else {
                            Intent resultActivity = new Intent(player3.this, GameOver.class);
                            startActivity(resultActivity);
                        }
                    }
                }
            }

        }
        if (v.getId() == R.id.button13) {
            int hand[] = getHand(3);
            result = cardPlayed(hand[0]);
            if (!result) {
                {Snackbar.make(v, "Invalid Play!", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();}
            }
            else {
                if (!isEndOfTrick()) {
                    Intent resultActivity = new Intent(player3.this, player0.class);
                    startActivity(resultActivity);
                }
                else {
                    endOfTrick();
                    if (!isEndOfRound()) {
                        int starter = getStarter();
                        switch (starter) {
                            case 1:
                                Intent resultActivity1 = new Intent(player3.this, player1.class);
                                startActivity(resultActivity1);
                                break;
                            case 2:
                                Intent resultActivity2 = new Intent(player3.this, player2.class);
                                startActivity(resultActivity2);
                                break;
                            case 3:
                                Intent resultActivity3 = new Intent(player3.this, player3.class);
                                startActivity(resultActivity3);
                                break;
                            default:
                                Intent resultActivity0 = new Intent(player3.this, player0.class);
                                startActivity(resultActivity0);
                                break;
                        }
                    }
                    else {
                        endOfRound();
                        if (!isGameOver()) {
                            shuffleDeal();
                            int starter = getStarter();
                            switch (starter) {
                                case 1:
                                    Intent resultActivity1 = new Intent(player3.this, player1.class);
                                    startActivity(resultActivity1);
                                    break;
                                case 2:
                                    Intent resultActivity2 = new Intent(player3.this, player2.class);
                                    startActivity(resultActivity2);
                                    break;
                                case 3:
                                    Intent resultActivity3 = new Intent(player3.this, player3.class);
                                    startActivity(resultActivity3);
                                    break;
                                default:
                                    Intent resultActivity0 = new Intent(player3.this, player0.class);
                                    startActivity(resultActivity0);
                                    break;
                            }
                        }
                        else {
                            Intent resultActivity = new Intent(player3.this, GameOver.class);
                            startActivity(resultActivity);
                        }
                    }
                }
            }

        }
    }


    public void assignDeckImages(int card, ImageView iV)
    {
        switch (card)
        {
            case 102:
                iV.setImageResource(R.drawable.clubs_2);
                break;
            case 103:
                iV.setImageResource(R.drawable.clubs_3);
                break;
            case 104:
                iV.setImageResource(R.drawable.clubs_4);
                break;
            case 105:
                iV.setImageResource(R.drawable.clubs_5);
                break;
            case 106:
                iV.setImageResource(R.drawable.clubs_6);
                break;
            case 107:
                iV.setImageResource(R.drawable.clubs_7);
                break;
            case 108:
                iV.setImageResource(R.drawable.clubs_8);
                break;
            case 109:
                iV.setImageResource(R.drawable.clubs_9);
                break;
            case 110:
                iV.setImageResource(R.drawable.clubs_10);
                break;
            case 111:
                iV.setImageResource(R.drawable.jack_of_clubs);
                break;
            case 112:
                iV.setImageResource(R.drawable.queen_of_clubs);
                break;
            case 113:
                iV.setImageResource(R.drawable.king_of_clubs);
                break;
            case 114:
                iV.setImageResource(R.drawable.ace_of_clubs);
                break;

            case 202:
                iV.setImageResource(R.drawable.diamonds_2);
                break;
            case 203:
                iV.setImageResource(R.drawable.diamonds_3);
                break;
            case 204:
                iV.setImageResource(R.drawable.diamonds_4);
                break;
            case 205:
                iV.setImageResource(R.drawable.diamonds_5);
                break;
            case 206:
                iV.setImageResource(R.drawable.diamonds_6);
                break;
            case 207:
                iV.setImageResource(R.drawable.diamonds_7);
                break;
            case 208:
                iV.setImageResource(R.drawable.diamonds_8);
                break;
            case 209:
                iV.setImageResource(R.drawable.diamonds_9);
                break;
            case 210:
                iV.setImageResource(R.drawable.diamonds_10);
                break;
            case 211:
                iV.setImageResource(R.drawable.jack_of_diamonds);
                break;
            case 212:
                iV.setImageResource(R.drawable.queen_of_diamond);
                break;
            case 213:
                iV.setImageResource(R.drawable.king_of_diamonds);
                break;
            case 214:
                iV.setImageResource(R.drawable.ace_of_diamonds);
                break;

            case 302:
                iV.setImageResource(R.drawable.hearts_2);
                break;
            case 303:
                iV.setImageResource(R.drawable.hearts_3);
                break;
            case 304:
                iV.setImageResource(R.drawable.hearts_4);
                break;
            case 305:
                iV.setImageResource(R.drawable.hearts_5);
                break;
            case 306:
                iV.setImageResource(R.drawable.hearts_6);
                break;
            case 307:
                iV.setImageResource(R.drawable.hearts_7);
                break;
            case 308:
                iV.setImageResource(R.drawable.hearts_8);
                break;
            case 309:
                iV.setImageResource(R.drawable.hearts_9);
                break;
            case 310:
                iV.setImageResource(R.drawable.hearts_10);
                break;
            case 311:
                iV.setImageResource(R.drawable.jack_of_hearts);
                break;
            case 312:
                iV.setImageResource(R.drawable.queen_of_hearts);
                break;
            case 313:
                iV.setImageResource(R.drawable.king_of_hearts);
                break;
            case 314:
                iV.setImageResource(R.drawable.ace_of_hearts);
                break;

            case 402:
                iV.setImageResource(R.drawable.spades_2);
                break;
            case 403:
                iV.setImageResource(R.drawable.spades_3);
                break;
            case 404:
                iV.setImageResource(R.drawable.spades_4);
                break;
            case 405:
                iV.setImageResource(R.drawable.spades_5);
                break;
            case 406:
                iV.setImageResource(R.drawable.spades_6);
                break;
            case 407:
                iV.setImageResource(R.drawable.spades_7);
                break;
            case 408:
                iV.setImageResource(R.drawable.spades_8);
                break;
            case 409:
                iV.setImageResource(R.drawable.spades_9);
                break;
            case 410:
                iV.setImageResource(R.drawable.spades_10);
                break;
            case 411:
                iV.setImageResource(R.drawable.jack_of_spades);
                break;
            case 412:
                iV.setImageResource(R.drawable.queen_of_spades);
                break;
            case 413:
                iV.setImageResource(R.drawable.king_of_spades);
                break;
            case 414:
                iV.setImageResource(R.drawable.ace_of_spades);
                break;
        }
    }

    public void assignImages(int card, Button button)
    {
        switch (card)
        {
            case 102:
                button.setBackgroundResource(R.drawable.clubs_2);
                break;
            case 103:
                button.setBackgroundResource(R.drawable.clubs_3);
                break;
            case 104:
                button.setBackgroundResource(R.drawable.clubs_4);
                break;
            case 105:
                button.setBackgroundResource(R.drawable.clubs_5);
                break;
            case 106:
                button.setBackgroundResource(R.drawable.clubs_6);
                break;
            case 107:
                button.setBackgroundResource(R.drawable.clubs_7);
                break;
            case 108:
                button.setBackgroundResource(R.drawable.clubs_8);
                break;
            case 109:
                button.setBackgroundResource(R.drawable.clubs_9);
                break;
            case 110:
                button.setBackgroundResource(R.drawable.clubs_10);
                break;
            case 111:
                button.setBackgroundResource(R.drawable.jack_of_clubs);
                break;
            case 112:
                button.setBackgroundResource(R.drawable.queen_of_clubs);
                break;
            case 113:
                button.setBackgroundResource(R.drawable.king_of_clubs);
                break;
            case 114:
                button.setBackgroundResource(R.drawable.ace_of_clubs);
                break;

            case 202:
                button.setBackgroundResource(R.drawable.diamonds_2);
                break;
            case 203:
                button.setBackgroundResource(R.drawable.diamonds_3);
                break;
            case 204:
                button.setBackgroundResource(R.drawable.diamonds_4);
                break;
            case 205:
                button.setBackgroundResource(R.drawable.diamonds_5);
                break;
            case 206:
                button.setBackgroundResource(R.drawable.diamonds_6);
                break;
            case 207:
                button.setBackgroundResource(R.drawable.diamonds_7);
                break;
            case 208:
                button.setBackgroundResource(R.drawable.diamonds_8);
                break;
            case 209:
                button.setBackgroundResource(R.drawable.diamonds_9);
                break;
            case 210:
                button.setBackgroundResource(R.drawable.diamonds_10);
                break;
            case 211:
                button.setBackgroundResource(R.drawable.jack_of_diamonds);
                break;
            case 212:
                button.setBackgroundResource(R.drawable.queen_of_diamond);
                break;
            case 213:
                button.setBackgroundResource(R.drawable.king_of_diamonds);
                break;
            case 214:
                button.setBackgroundResource(R.drawable.ace_of_diamonds);
                break;

            case 302:
                button.setBackgroundResource(R.drawable.hearts_2);
                break;
            case 303:
                button.setBackgroundResource(R.drawable.hearts_3);
                break;
            case 304:
                button.setBackgroundResource(R.drawable.hearts_4);
                break;
            case 305:
                button.setBackgroundResource(R.drawable.hearts_5);
                break;
            case 306:
                button.setBackgroundResource(R.drawable.hearts_6);
                break;
            case 307:
                button.setBackgroundResource(R.drawable.hearts_7);
                break;
            case 308:
                button.setBackgroundResource(R.drawable.hearts_8);
                break;
            case 309:
                button.setBackgroundResource(R.drawable.hearts_9);
                break;
            case 310:
                button.setBackgroundResource(R.drawable.hearts_10);
                break;
            case 311:
                button.setBackgroundResource(R.drawable.jack_of_hearts);
                break;
            case 312:
                button.setBackgroundResource(R.drawable.queen_of_hearts);
                break;
            case 313:
                button.setBackgroundResource(R.drawable.king_of_hearts);
                break;
            case 314:
                button.setBackgroundResource(R.drawable.ace_of_hearts);
                break;

            case 402:
                button.setBackgroundResource(R.drawable.spades_2);
                break;
            case 403:
                button.setBackgroundResource(R.drawable.spades_3);
                break;
            case 404:
                button.setBackgroundResource(R.drawable.spades_4);
                break;
            case 405:
                button.setBackgroundResource(R.drawable.spades_5);
                break;
            case 406:
                button.setBackgroundResource(R.drawable.spades_6);
                break;
            case 407:
                button.setBackgroundResource(R.drawable.spades_7);
                break;
            case 408:
                button.setBackgroundResource(R.drawable.spades_8);
                break;
            case 409:
                button.setBackgroundResource(R.drawable.spades_9);
                break;
            case 410:
                button.setBackgroundResource(R.drawable.spades_10);
                break;
            case 411:
                button.setBackgroundResource(R.drawable.jack_of_spades);
                break;
            case 412:
                button.setBackgroundResource(R.drawable.queen_of_spades);
                break;
            case 413:
                button.setBackgroundResource(R.drawable.king_of_spades);
                break;
            case 414:
                button.setBackgroundResource(R.drawable.ace_of_spades);
                break;
        }
    }

    native int getStarter();
    native String getName(int player);
    native int[] getHand(int player);
    native int[] getPlayedDeck();
    native boolean cardPlayed(int card);
    native boolean isEndOfTrick();
    native void endOfTrick();
    native boolean isEndOfRound();
    native void endOfRound();
    native void shuffleDeal();
    native boolean isGameOver();
}
