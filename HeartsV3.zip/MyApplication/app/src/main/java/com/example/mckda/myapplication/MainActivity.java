package com.example.mckda.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements OnClickListener {

    // Used to load the 'native-lib' library on application startup.
    static {
        System.loadLibrary("native-lib");
    }

    private Button button;
    private EditText et;
    private EditText et2;
    private EditText et3;
    private EditText et4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = (Button) findViewById(R.id.nextplayer);
        button.setOnClickListener(this);

        et = (EditText) findViewById(R.id.editText);
        et2 = (EditText) findViewById(R.id.editText2);
        et3 = (EditText) findViewById(R.id.editText3);
        et4 = (EditText) findViewById(R.id.editText4);


        // Example of a call to a native method

    }

    public void onClick(View v)
    {
        if(v.getId()==R.id.nextplayer) {

            String text = et.getText().toString();
            String text2 = et2.getText().toString();
            String text3 = et3.getText().toString();
            String text4 = et4.getText().toString();

            setNames(text,text2,text3,text4);
            TextView tv = (TextView) findViewById(R.id.sample_text);
            tv.setText(getName(2));

        }

    }


    /**
     * A native method that is implemented by the 'native-lib' native library,
     * which is packaged with this application.
     */
    public native String stringFromJNI();
    public native void setCapScore(int capScore);
    public native int getCapScore();
    public native void setNames(String text,String text2, String text3, String text4);
    public native String getName(int val);
    public native void shuffleDeal();
    public native boolean isEndOfTrick();
    public native void endOfTrick();
    public native boolean isEndOfRound();
    public native void endOfRound();
    public native boolean isGameOver();
    public native int getStarter();
    public native int getCurrentPlayer();
    public native int[] getScores();
    public native int getWinner();
}
