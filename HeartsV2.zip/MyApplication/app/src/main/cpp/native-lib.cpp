#include <jni.h>
#include <string>
#include "Game.h"
#include "Player.h"
#include "Card.h"
#include <iostream>
#include <vector>

Game game;

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_mckda_myapplication_MainActivity_stringFromJNI(
        JNIEnv *env,
        jobject /* this */){

    static int player = 0;

    std::string name ="Mckenna";
    std::string name1 ="Shreya";
    std::string name2 ="Sarah";
    std::string name3 ="Mary";
    std::string hello;
    game.setNames(name,name1,name2,name3);

    switch (player) {
        case 0: {
            hello = game.Player0.getName();
            break;
        }
        case 1: {
            hello = game.Player1.getName();
            break;
        }
        case 2: {
            hello = game.Player2.getName();
            break;
        }
        default: {
            hello = game.Player3.getName();
            break;
        }
    }

    if (player == 3)
        player = 0;
    else
        player++;

    return env->NewStringUTF(hello.c_str());
}


extern "C"
JNIEXPORT void JNICALL Java_com_example_mckda_myapplication_MainActivity_setCapScore(
        JNIEnv *env,
        jobject /* this */,
        jint capScore) {
    //Sets cap score from inputted value
    game.setFinalScore(capScore);
    return;
}

extern "C"
JNIEXPORT jint JNICALL Java_com_example_mckda_myapplication_MainActivity_getCapScore(
        JNIEnv *env,
        jobject /* this */) {
    //DELETE: returns cap score (created for testing)
    int score = game.finalScore;
    return score;
}

extern "C"
JNIEXPORT void JNICALL Java_com_example_mckda_myapplication_MainActivity_setNames(
        JNIEnv *env,
        jobject /* this */,
        jstring name, jstring name1, jstring name2, jstring name3) {
    //Sets player names

    const char *str = (*env).GetStringUTFChars(name,0);
    std::string stringName (str);
    const char *str1 = (*env).GetStringUTFChars(name1,0);
    std::string stringName1 (str1);
    const char *str2 = (*env).GetStringUTFChars(name2,0);
    std::string stringName2 (str2);
    const char *str3 = (*env).GetStringUTFChars(name3,0);
    std::string stringName3 (str3);
    game.setNames(stringName,stringName1,stringName2,stringName3);
    return;
}

extern "C"
JNIEXPORT jstring JNICALL Java_com_example_mckda_myapplication_MainActivity_getName(
        JNIEnv *env,
        jobject /* this */,
        jint val) {

    //Returns player name of player val; val needs to be 0-3.
    std::string name   ;
    switch ((int)val) {
        case 0: {
            name = game.Player0.getName();
            break;
        }
        case 1: {
            name = game.Player1.getName();
            break;
        }
        case 2: {
            name = game.Player2.getName();
            break;
        }
        default: {
            name = game.Player3.getName();
            break;
        }
    }
    return env->NewStringUTF(name.c_str());
}

extern "C"
JNIEXPORT void JNICALL Java_com_example_mckda_myapplication_MainActivity_shuffleDeal(
        JNIEnv *env,
        jobject /* this */) {
    //Calls the shuffleDeal function on the game object
    game.shuffleDeal();
    return;
}

extern "C"
JNIEXPORT jboolean JNICALL Java_com_example_mckda_myapplication_MainActivity_isEndOfTrick(
        JNIEnv *env,
        jobject /* this */) {

    //Returns true if it's the end of the trick, false if not
    bool result = game.isEndOfTrick();
    if (result)
        return JNI_TRUE;
    else
        return JNI_FALSE;
}

extern "C"
JNIEXPORT void JNICALL Java_com_example_mckda_myapplication_MainActivity_endOfTrick(
        JNIEnv *env,
        jobject /* this */) {
    //Calls the endOfTrick function on the game object
    game.endOfTrick();
    return;
}

extern "C"
JNIEXPORT jboolean JNICALL Java_com_example_mckda_myapplication_MainActivity_isEndOfRound(
        JNIEnv *env,
        jobject /* this */) {
    //Returns true if it's the end of the round, false if not
    bool result = game.isEndOfRound();
    if (result)
        return JNI_TRUE;
    else
        return JNI_FALSE;
}

extern "C"
JNIEXPORT void JNICALL Java_com_example_mckda_myapplication_MainActivity_endOfRound(
        JNIEnv *env,
        jobject /* this */) {
    //Calls the endOfRound function on the game object
    game.endOfRound();
    return;
}

extern "C"
JNIEXPORT jboolean JNICALL Java_com_example_mckda_myapplication_MainActivity_isGameOver(
        JNIEnv *env,
        jobject /* this */) {
    //Returns true if the game is over, false otherwise
    bool result = game.isGameOver();
    if (result)
        return JNI_TRUE;
    else
        return JNI_FALSE;
}

extern "C"
JNIEXPORT jint JNICALL Java_com_example_mckda_myapplication_MainActivity_getStarter(
        JNIEnv *env,
        jobject /* this */) {
    //Returns index (0-3) of player that is starting trick
    return game.getStarter();
}

extern "C"
JNIEXPORT jint JNICALL Java_com_example_mckda_myapplication_MainActivity_getCurrentPlayer(
        JNIEnv *env,
        jobject /* this */) {
    //Returns index (0-3) of the current player
    return game.getCurrentPlayer();
}

extern "C"
JNIEXPORT jintArray JNICALL Java_com_example_mckda_myapplication_MainActivity_getScores(
        JNIEnv *env,
        jobject /* this */) {
    //Returns an array of the scores
    int * scores;
    scores = game.getScores();
    jintArray newscores = env->NewIntArray(4);
    env->SetIntArrayRegion(newscores,0,4,scores);
    return newscores;
}

extern "C"
JNIEXPORT jint JNICALL Java_com_example_mckda_myapplication_MainActivity_getWinner(
        JNIEnv *env,
        jobject /* this */) {
    //Returns index (0-3) of winner
    return game.getWinner();
}