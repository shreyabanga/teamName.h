package com.example.sarah.heartz;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;

public class FinalScoreInput extends AppCompatActivity implements OnClickListener {

    static {
        System.loadLibrary("native-lib");
    }

    private EditText et;
    private View v;
    private Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_final_score_input);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        v = (View) findViewById(R.id.vieww);
        v.setOnClickListener(this);

        et = (EditText) findViewById(R.id.editText);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }

    public void onClick(View v) {
        if (v.getId() == R.id.button) {

            String text = et.getText().toString();

            setCapScore(Integer.parseInt(text)); //initializing the cap score names


        } else {
            et.onEditorAction(EditorInfo.IME_ACTION_DONE);
        }


    }

    public native void setCapScore(int capScore);
}
