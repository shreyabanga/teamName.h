package com.example.sarah.heartz;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;

import java.util.ArrayList;
import java.util.Collections;



public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    // Used to load the 'native-lib' library on application startup.
    static {
        System.loadLibrary("native-lib");
    }


    private Button button;
    private Button button2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //On create, creates the layout and makes the buttons clickable
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        button = findViewById(R.id.button1);
        button.setOnClickListener(this);

        button2 = findViewById(R.id.button2);
        button2.setOnClickListener(this);


    }

    public void onClick(View v) {

        //If the start button is pushed, it starts the game by clearing any scores that might exist
        //from previous games and going to the name input screen
        if (v.getId() == R.id.button1) {
            setScoresZero();
            Intent resultActivity = new Intent(MainActivity.this, nameInput.class);
            startActivity(resultActivity);

        //If the rules button is pushed, goes to the rules (scrolling) screen
        } else {

            Intent resultActivity = new Intent(MainActivity.this, ScrollingActivity.class);
            startActivity(resultActivity);

        }
    }



    native public void setScoresZero();
}
