#include <jni.h>
#include <string>
#include "Game.h"
#include "Player.h"
#include "Card.h"
#include <iostream>
#include <vector>

Game game;

extern "C"
JNIEXPORT jboolean JNICALL Java_com_example_sarah_heartz_FinalScoreInput_setCapScore(
        JNIEnv *env,
        jobject /* this */,
        jint capScore) {
    //Sets cap score from inputted value
    bool result=game.setFinalScore(capScore);
    if(result)
        return JNI_TRUE;
    return JNI_FALSE;
}


extern "C"
JNIEXPORT void JNICALL Java_com_example_sarah_heartz_nameInput_setNames(
        JNIEnv *env,
        jobject /* this */,
        jstring name, jstring name1, jstring name2, jstring name3) {
    //Sets player names

    const char *str = (*env).GetStringUTFChars(name,0);
    std::string stringName (str);
    const char *str1 = (*env).GetStringUTFChars(name1,0);
    std::string stringName1 (str1);
    const char *str2 = (*env).GetStringUTFChars(name2,0);
    std::string stringName2 (str2);
    const char *str3 = (*env).GetStringUTFChars(name3,0);
    std::string stringName3 (str3);
    game.setNames(stringName,stringName1,stringName2,stringName3);
    return;
}

extern "C"
JNIEXPORT jstring JNICALL Java_com_example_sarah_heartz_player0_getName(
        JNIEnv *env,
        jobject /* this */,
        jint val) {

    //Returns player name of player val; val needs to be 0-3.
    std::string name   ;
    name = game.getName(val);
    return env->NewStringUTF(name.c_str());
}

extern "C"
JNIEXPORT jstring JNICALL Java_com_example_sarah_heartz_player1_getName(
        JNIEnv *env,
        jobject /* this */,
        jint val) {

    //Returns player name of player val; val needs to be 0-3.
    std::string name   ;
    name = game.getName(val);
    return env->NewStringUTF(name.c_str());
}

extern "C"
JNIEXPORT jstring JNICALL Java_com_example_sarah_heartz_player2_getName(
        JNIEnv *env,
        jobject /* this */,
        jint val) {

    //Returns player name of player val; val needs to be 0-3.
    std::string name   ;
    name = game.getName(val);
    return env->NewStringUTF(name.c_str());
}

extern "C"
JNIEXPORT jstring JNICALL Java_com_example_sarah_heartz_player3_getName(
        JNIEnv *env,
        jobject /* this */,
        jint val) {

    //Returns player name of player val; val needs to be 0-3.
    std::string name   ;
    name = game.getName(val);
    return env->NewStringUTF(name.c_str());
}

extern "C"
JNIEXPORT void JNICALL Java_com_example_sarah_heartz_FinalScoreInput_shuffleDeal(
        JNIEnv *env,
        jobject /* this */) {
    //Calls the shuffleDeal function on the game object
    game.shuffleDeal();
}

extern "C"
JNIEXPORT void JNICALL Java_com_example_sarah_heartz_player0_shuffleDeal(
        JNIEnv *env,
        jobject /* this */) {
    //Calls the shuffleDeal function on the game object
    game.shuffleDeal();
}

extern "C"
JNIEXPORT void JNICALL Java_com_example_sarah_heartz_player1_shuffleDeal(
        JNIEnv *env,
        jobject /* this */) {
    //Calls the shuffleDeal function on the game object
    game.shuffleDeal();
}

extern "C"
JNIEXPORT void JNICALL Java_com_example_sarah_heartz_player2_shuffleDeal(
        JNIEnv *env,
        jobject /* this */) {
    //Calls the shuffleDeal function on the game object
    game.shuffleDeal();
}

extern "C"
JNIEXPORT void JNICALL Java_com_example_sarah_heartz_player3_shuffleDeal(
        JNIEnv *env,
        jobject /* this */) {
    //Calls the shuffleDeal function on the game object
    game.shuffleDeal();
}


extern "C"
JNIEXPORT jboolean JNICALL Java_com_example_sarah_heartz_player0_isEndOfTrick(
        JNIEnv *env,
        jobject /* this */) {

    //Returns true if it's the end of the trick, false if not
    bool result = game.isEndOfTrick();
    if (result)
        return JNI_TRUE;
    else
        return JNI_FALSE;
}

extern "C"
JNIEXPORT jboolean JNICALL Java_com_example_sarah_heartz_player1_isEndOfTrick(
        JNIEnv *env,
        jobject /* this */) {

    //Returns true if it's the end of the trick, false if not
    bool result = game.isEndOfTrick();
    if (result)
        return JNI_TRUE;
    else
        return JNI_FALSE;
}
extern "C"
JNIEXPORT jboolean JNICALL Java_com_example_sarah_heartz_player2_isEndOfTrick(
        JNIEnv *env,
        jobject /* this */) {

    //Returns true if it's the end of the trick, false if not
    bool result = game.isEndOfTrick();
    if (result)
        return JNI_TRUE;
    else
        return JNI_FALSE;
}

extern "C"
JNIEXPORT jboolean JNICALL Java_com_example_sarah_heartz_player3_isEndOfTrick(
        JNIEnv *env,
        jobject /* this */) {

    //Returns true if it's the end of the trick, false if not
    bool result = game.isEndOfTrick();
    if (result)
        return JNI_TRUE;
    else
        return JNI_FALSE;
}

extern "C"
JNIEXPORT void JNICALL Java_com_example_sarah_heartz_player0_endOfTrick(
        JNIEnv *env,
        jobject /* this */) {
    //Calls the endOfTrick function on the game object
    game.endOfTrick();
    return;
}

extern "C"
JNIEXPORT void JNICALL Java_com_example_sarah_heartz_player1_endOfTrick(
        JNIEnv *env,
        jobject /* this */) {
    //Calls the endOfTrick function on the game object
    game.endOfTrick();
    return;
}
extern "C"
JNIEXPORT void JNICALL Java_com_example_sarah_heartz_player2_endOfTrick(
        JNIEnv *env,
        jobject /* this */) {
    //Calls the endOfTrick function on the game object
    game.endOfTrick();
    return;
}
extern "C"
JNIEXPORT void JNICALL Java_com_example_sarah_heartz_player3_endOfTrick(
        JNIEnv *env,
        jobject /* this */) {
    //Calls the endOfTrick function on the game object
    game.endOfTrick();
    return;
}


extern "C"
JNIEXPORT jboolean JNICALL Java_com_example_sarah_heartz_player0_isEndOfRound(
        JNIEnv *env,
        jobject /* this */) {
    //Returns true if it's the end of the round, false if not
    bool result = game.isEndOfRound();
    if (result)
        return JNI_TRUE;
    else
        return JNI_FALSE;
}
extern "C"
JNIEXPORT jboolean JNICALL Java_com_example_sarah_heartz_player1_isEndOfRound(
        JNIEnv *env,
        jobject /* this */) {
    //Returns true if it's the end of the round, false if not
    bool result = game.isEndOfRound();
    if (result)
        return JNI_TRUE;
    else
        return JNI_FALSE;
}
extern "C"
JNIEXPORT jboolean JNICALL Java_com_example_sarah_heartz_player2_isEndOfRound(
        JNIEnv *env,
        jobject /* this */) {
    //Returns true if it's the end of the round, false if not
    bool result = game.isEndOfRound();
    if (result)
        return JNI_TRUE;
    else
        return JNI_FALSE;
}
extern "C"
JNIEXPORT jboolean JNICALL Java_com_example_sarah_heartz_player3_isEndOfRound(
        JNIEnv *env,
        jobject /* this */) {
    //Returns true if it's the end of the round, false if not
    bool result = game.isEndOfRound();
    if (result)
        return JNI_TRUE;
    else
        return JNI_FALSE;
}

extern "C"
JNIEXPORT void JNICALL Java_com_example_sarah_heartz_player0_endOfRound(
        JNIEnv *env,
        jobject /* this */) {
    //Calls the endOfRound function on the game object
    game.endOfRound();
    return;
}

extern "C"
JNIEXPORT void JNICALL Java_com_example_sarah_heartz_player1_endOfRound(
        JNIEnv *env,
        jobject /* this */) {
    //Calls the endOfRound function on the game object
    game.endOfRound();
    return;
}
extern "C"
JNIEXPORT void JNICALL Java_com_example_sarah_heartz_player2_endOfRound(
        JNIEnv *env,
        jobject /* this */) {
    //Calls the endOfRound function on the game object
    game.endOfRound();
    return;
}
extern "C"
JNIEXPORT void JNICALL Java_com_example_sarah_heartz_player3_endOfRound(
        JNIEnv *env,
        jobject /* this */) {
    //Calls the endOfRound function on the game object
    game.endOfRound();
    return;
}

extern "C"
JNIEXPORT jboolean JNICALL Java_com_example_sarah_heartz_player0_isGameOver(
        JNIEnv *env,
        jobject /* this */) {
    //Returns true if the game is over, false otherwise
    bool result = game.isGameOver();
    if (result)
        return JNI_TRUE;
    else
        return JNI_FALSE;
}
extern "C"
JNIEXPORT jboolean JNICALL Java_com_example_sarah_heartz_player1_isGameOver(
        JNIEnv *env,
        jobject /* this */) {
    //Returns true if the game is over, false otherwise
    bool result = game.isGameOver();
    if (result)
        return JNI_TRUE;
    else
        return JNI_FALSE;
}
extern "C"
JNIEXPORT jboolean JNICALL Java_com_example_sarah_heartz_player2_isGameOver(
        JNIEnv *env,
        jobject /* this */) {
    //Returns true if the game is over, false otherwise
    bool result = game.isGameOver();
    if (result)
        return JNI_TRUE;
    else
        return JNI_FALSE;
}
extern "C"
JNIEXPORT jboolean JNICALL Java_com_example_sarah_heartz_player3_isGameOver(
        JNIEnv *env,
        jobject /* this */) {
    //Returns true if the game is over, false otherwise
    bool result = game.isGameOver();
    if (result)
        return JNI_TRUE;
    else
        return JNI_FALSE;
}

extern "C"
JNIEXPORT jint JNICALL Java_com_example_sarah_heartz_FinalScoreInput_getStarter(
        JNIEnv *env,
        jobject /* this */) {
    //Returns index (0-3) of player that is starting trick
    return game.getStarter();
}


extern "C"
JNIEXPORT jint JNICALL Java_com_example_sarah_heartz_player0_getStarter(
        JNIEnv *env,
        jobject /* this */) {
    //Returns index (0-3) of player that is starting trick
    return game.getStarter();
}

extern "C"
JNIEXPORT jint JNICALL Java_com_example_sarah_heartz_player1_getStarter(
        JNIEnv *env,
        jobject /* this */) {
    //Returns index (0-3) of player that is starting trick
    return game.getStarter();
}
extern "C"
JNIEXPORT jint JNICALL Java_com_example_sarah_heartz_player2_getStarter(
        JNIEnv *env,
        jobject /* this */) {
    //Returns index (0-3) of player that is starting trick
    return game.getStarter();
}
extern "C"
JNIEXPORT jint JNICALL Java_com_example_sarah_heartz_player3_getStarter(
        JNIEnv *env,
        jobject /* this */) {
    //Returns index (0-3) of player that is starting trick
    return game.getStarter();
}

extern "C"
JNIEXPORT jint JNICALL Java_com_example_sarah_heartz_MainActivity_getCurrentPlayer(
        JNIEnv *env,
        jobject /* this */) {
    //Returns index (0-3) of the current player
    return game.getCurrentPlayer();
}

extern "C"
JNIEXPORT jintArray JNICALL Java_com_example_sarah_heartz_MainActivity_getScores(
        JNIEnv *env,
        jobject /* this */) {
    //Returns an array of the scores
    int * scores;
    scores = game.getScores();
    jintArray newscores = env->NewIntArray(4);
    env->SetIntArrayRegion(newscores,0,4,scores);
    return newscores;
}

extern "C"
JNIEXPORT jint JNICALL Java_com_example_sarah_heartz_MainActivity_getWinner(
        JNIEnv *env,
        jobject /* this */) {
    //Returns index (0-3) of winner
    return game.getWinner();
}

extern "C"
JNIEXPORT jintArray JNICALL Java_com_example_sarah_heartz_player0_getHand(
        JNIEnv *env,
        jobject /* this */,
        jint player) {
    //Returns the player's hand as a jintArray. Cards are in integer representation.
    int size;
    size = game.getHandSize(player);
    int * hand;
    hand = game.getPlayerHand(player);
    jintArray newHand = env->NewIntArray(size);
    env->SetIntArrayRegion(newHand,0,size,hand);
    return newHand;
}
extern "C"
JNIEXPORT jintArray JNICALL Java_com_example_sarah_heartz_player1_getHand(
        JNIEnv *env,
        jobject /* this */,
        jint player) {
    //Returns the player's hand as a jintArray. Cards are in integer representation.
    int size;
    size = game.getHandSize(player);
    int * hand;
    hand = game.getPlayerHand(player);
    jintArray newHand = env->NewIntArray(size);
    env->SetIntArrayRegion(newHand,0,size,hand);
    return newHand;
}
extern "C"
JNIEXPORT jintArray JNICALL Java_com_example_sarah_heartz_player2_getHand(
        JNIEnv *env,
        jobject /* this */,
        jint player) {
    //Returns the player's hand as a jintArray. Cards are in integer representation.
    int size;
    size = game.getHandSize(player);
    int * hand;
    hand = game.getPlayerHand(player);
    jintArray newHand = env->NewIntArray(size);
    env->SetIntArrayRegion(newHand,0,size,hand);
    return newHand;
}
extern "C"
JNIEXPORT jintArray JNICALL Java_com_example_sarah_heartz_player3_getHand(
        JNIEnv *env,
        jobject /* this */,
        jint player) {
    //Returns the player's hand as a jintArray. Cards are in integer representation.
    int size;
    size = game.getHandSize(player);
    int * hand;
    hand = game.getPlayerHand(player);
    jintArray newHand = env->NewIntArray(size);
    env->SetIntArrayRegion(newHand,0,size,hand);
    return newHand;
}

extern "C"
JNIEXPORT jintArray JNICALL Java_com_example_sarah_heartz_player0_getPlayedDeck(
        JNIEnv *env,
        jobject /* this */) {
    //Returns playedDeck as a jintArray with the cards in integer representation
    int * playedDeck;
    int size = game.getPlayedDeckSize();
    playedDeck = game.getPlayedDeck();
    int * playedDeck1 = new int[size];
    int count = 0;
    for (int i=0; i<4; i++) {
        if (playedDeck[i]!=0) {
            playedDeck1[count] = playedDeck[i];
            count++;
        }
    }
    jintArray newPlayedDeck = env ->NewIntArray(size);
    env->SetIntArrayRegion(newPlayedDeck,0,size,playedDeck1);
    return newPlayedDeck;
}

extern "C"
JNIEXPORT jintArray JNICALL Java_com_example_sarah_heartz_player1_getPlayedDeck(
        JNIEnv *env,
        jobject /* this */) {
    //Returns playedDeck as a jintArray with the cards in integer representation
    int * playedDeck;
    int size = game.getPlayedDeckSize();
    playedDeck = game.getPlayedDeck();
    int * playedDeck1 = new int[size];
    int count = 0;
    for (int i=0; i<4; i++) {
        if (playedDeck[i]!=0) {
            playedDeck1[count] = playedDeck[i];
            count++;
        }
    }
    jintArray newPlayedDeck = env ->NewIntArray(size);
    env->SetIntArrayRegion(newPlayedDeck,0,size,playedDeck1);
    return newPlayedDeck;
}
extern "C"
JNIEXPORT jintArray JNICALL Java_com_example_sarah_heartz_player2_getPlayedDeck(
        JNIEnv *env,
        jobject /* this */) {
    //Returns playedDeck as a jintArray with the cards in integer representation
    int * playedDeck;
    int size = game.getPlayedDeckSize();
    playedDeck = game.getPlayedDeck();
    int * playedDeck1 = new int[size];
    int count = 0;
    for (int i=0; i<4; i++) {
        if (playedDeck[i]!=0) {
            playedDeck1[count] = playedDeck[i];
            count++;
        }
    }
    jintArray newPlayedDeck = env ->NewIntArray(size);
    env->SetIntArrayRegion(newPlayedDeck,0,size,playedDeck1);
    return newPlayedDeck;
}

extern "C"
JNIEXPORT jintArray JNICALL Java_com_example_sarah_heartz_player3_getPlayedDeck(
        JNIEnv *env,
        jobject /* this */) {
    //Returns playedDeck as a jintArray with the cards in integer representation
    int * playedDeck;
    int size = game.getPlayedDeckSize();
    playedDeck = game.getPlayedDeck();
    int * playedDeck1 = new int[size];
    int count = 0;
    for (int i=0; i<4; i++) {
        if (playedDeck[i]!=0) {
            playedDeck1[count] = playedDeck[i];
            count++;
        }
    }
    jintArray newPlayedDeck = env ->NewIntArray(size);
    env->SetIntArrayRegion(newPlayedDeck,0,size,playedDeck1);
    return newPlayedDeck;
}


extern "C"
JNIEXPORT jboolean JNICALL Java_com_example_sarah_heartz_player0_cardPlayed(
        JNIEnv *env,
        jobject /* this */,
        jint card) {

    //Returns true if the card is valid (i.e. can be played) and false if not. If the card is valid,
    //it's played.
    char suit;
    char value;
    if (card < 200)
        suit = 'C';
    else if (card < 300)
        suit = 'D';
    else if (card < 400)
        suit = 'H';
    else
        suit = 'S';

    int valueInt = card%100;
    switch (valueInt) {
        case 2: {
            value = '2';
            break;
        }
        case 3: {
            value = '3';
            break;
        }
        case 4: {
            value = '4';
            break;
        }
        case 5: {
            value = '5';
            break;
        }
        case 6: {
            value = '6';
            break;
        }
        case 7: {
            value = '7';
            break;
        }
        case 8: {
            value = '8';
            break;
        }
        case 9: {
            value = '9';
            break;
        }
        case 10: {
            value = 'T';
            break;
        }
        case 11: {
            value = 'J';
            break;
        }
        case 12: {
            value = 'Q';
            break;
        }
        case 13: {
            value = 'K';
            break;
        }
        default: {
            value = 'A';
            break;
        }
    }
    Card newCard(suit,value);
    bool result = game.cardPlayed(newCard);
    if (result)
        return JNI_TRUE;
    else
        return JNI_FALSE;
}
extern "C"
JNIEXPORT jboolean JNICALL Java_com_example_sarah_heartz_player1_cardPlayed(
        JNIEnv *env,
        jobject /* this */,
        jint card) {

    //Returns true if the card is valid (i.e. can be played) and false if not. If the card is valid,
    //it's played.
    char suit;
    char value;
    if (card < 200)
        suit = 'C';
    else if (card < 300)
        suit = 'D';
    else if (card < 400)
        suit = 'H';
    else
        suit = 'S';

    int valueInt = card%100;
    switch (valueInt) {
        case 2: {
            value = '2';
            break;
        }
        case 3: {
            value = '3';
            break;
        }
        case 4: {
            value = '4';
            break;
        }
        case 5: {
            value = '5';
            break;
        }
        case 6: {
            value = '6';
            break;
        }
        case 7: {
            value = '7';
            break;
        }
        case 8: {
            value = '8';
            break;
        }
        case 9: {
            value = '9';
            break;
        }
        case 10: {
            value = 'T';
            break;
        }
        case 11: {
            value = 'J';
            break;
        }
        case 12: {
            value = 'Q';
            break;
        }
        case 13: {
            value = 'K';
            break;
        }
        default: {
            value = 'A';
            break;
        }
    }
    Card newCard(suit,value);
    bool result = game.cardPlayed(newCard);
    if (result)
        return JNI_TRUE;
    else
        return JNI_FALSE;
}
extern "C"
JNIEXPORT jboolean JNICALL Java_com_example_sarah_heartz_player2_cardPlayed(
        JNIEnv *env,
        jobject /* this */,
        jint card) {

    //Returns true if the card is valid (i.e. can be played) and false if not. If the card is valid,
    //it's played.
    char suit;
    char value;
    if (card < 200)
        suit = 'C';
    else if (card < 300)
        suit = 'D';
    else if (card < 400)
        suit = 'H';
    else
        suit = 'S';

    int valueInt = card%100;
    switch (valueInt) {
        case 2: {
            value = '2';
            break;
        }
        case 3: {
            value = '3';
            break;
        }
        case 4: {
            value = '4';
            break;
        }
        case 5: {
            value = '5';
            break;
        }
        case 6: {
            value = '6';
            break;
        }
        case 7: {
            value = '7';
            break;
        }
        case 8: {
            value = '8';
            break;
        }
        case 9: {
            value = '9';
            break;
        }
        case 10: {
            value = 'T';
            break;
        }
        case 11: {
            value = 'J';
            break;
        }
        case 12: {
            value = 'Q';
            break;
        }
        case 13: {
            value = 'K';
            break;
        }
        default: {
            value = 'A';
            break;
        }
    }
    Card newCard(suit,value);
    bool result = game.cardPlayed(newCard);
    if (result)
        return JNI_TRUE;
    else
        return JNI_FALSE;
}
extern "C"
JNIEXPORT jboolean JNICALL Java_com_example_sarah_heartz_player3_cardPlayed(
        JNIEnv *env,
        jobject /* this */,
        jint card) {

    //Returns true if the card is valid (i.e. can be played) and false if not. If the card is valid,
    //it's played.
    char suit;
    char value;
    if (card < 200)
        suit = 'C';
    else if (card < 300)
        suit = 'D';
    else if (card < 400)
        suit = 'H';
    else
        suit = 'S';

    int valueInt = card%100;
    switch (valueInt) {
        case 2: {
            value = '2';
            break;
        }
        case 3: {
            value = '3';
            break;
        }
        case 4: {
            value = '4';
            break;
        }
        case 5: {
            value = '5';
            break;
        }
        case 6: {
            value = '6';
            break;
        }
        case 7: {
            value = '7';
            break;
        }
        case 8: {
            value = '8';
            break;
        }
        case 9: {
            value = '9';
            break;
        }
        case 10: {
            value = 'T';
            break;
        }
        case 11: {
            value = 'J';
            break;
        }
        case 12: {
            value = 'Q';
            break;
        }
        case 13: {
            value = 'K';
            break;
        }
        default: {
            value = 'A';
            break;
        }
    }
    Card newCard(suit,value);
    bool result = game.cardPlayed(newCard);
    if (result)
        return JNI_TRUE;
    else
        return JNI_FALSE;
}


