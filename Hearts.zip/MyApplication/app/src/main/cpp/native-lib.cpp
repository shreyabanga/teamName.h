#include <jni.h>
#include <string>
#include "Game.h"
#include "Player.h"
#include "Card.h"
#include <iostream>

Game game;



extern "C" JNIEXPORT jstring JNICALL
Java_com_example_mckda_myapplication_MainActivity_stringFromJNI(
        JNIEnv *env,
        jobject /* this */){

    static int player = 0;

    std::string name ="Mckenna";
    std::string name1 ="Shreya";
    std::string name2 ="Sarah";
    std::string name3 ="Mary";
    std::string hello;
    game.setNames(name,name1,name2,name3);

    switch (player) {
        case 0: {
            hello = game.Player0.getName();
            break;
        }
        case 1: {
            hello = game.Player1.getName();
            break;
        }
        case 2: {
            hello = game.Player2.getName();
            break;
        }
        default: {
            hello = game.Player3.getName();
            break;
        }
    }

    if (player == 3)
        player = 0;
    else
        player++;

    return env->NewStringUTF(hello.c_str());
}

extern "C"
JNIEXPORT void JNICALL Java_com_example_mckda_myapplication_MainActivity_setCapScore(
        JNIEnv *env,
        jobject /* this */,
        jint capScore) {

    game.setFinalScore(capScore);
    return;
}

extern "C"
JNIEXPORT jint JNICALL Java_com_example_mckda_myapplication_MainActivity_getCapScore(
        JNIEnv *env,
        jobject /* this */) {
    int score = game.finalScore;
    return score;
}

extern "C"
JNIEXPORT void JNICALL Java_com_example_mckda_myapplication_MainActivity_setNames(
        JNIEnv *env,
        jobject /* this */,
        jstring name, jstring name1, jstring name2, jstring name3) {

    const char *str = (*env).GetStringUTFChars(name,0);
    std::string stringName (str);
    const char *str1 = (*env).GetStringUTFChars(name1,0);
    std::string stringName1 (str1);
    const char *str2 = (*env).GetStringUTFChars(name2,0);
    std::string stringName2 (str2);
    const char *str3 = (*env).GetStringUTFChars(name3,0);
    std::string stringName3 (str3);
    game.setNames(stringName,stringName1,stringName2,stringName3);
    return;
}

extern "C"
JNIEXPORT jstring JNICALL Java_com_example_mckda_myapplication_MainActivity_getNames(
        JNIEnv *env,
        jobject /* this */,
        jint val) {

    std::string hello;
    switch (val) {
        case 0: {
            hello = game.Player0.getName();
            break;
        }
        case 1: {
            hello = game.Player1.getName();
            break;
        }
        case 2: {
            hello = game.Player2.getName();
            break;
        }
        default: {
            hello = game.Player3.getName();
            break;
        }
    }
    return env->NewStringUTF(hello.c_str());
}

extern "C"
JNIEXPORT void JNICALL Java_com_example_mckda_myapplication_MainActivity_shuffleDeal(
        JNIEnv *env,
        jobject /* this */) {

    game.shuffleDeal();
    return;
}

