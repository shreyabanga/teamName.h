package com.example.sarah.heartz;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;



public class nameInput extends AppCompatActivity implements OnClickListener{

    static {
        System.loadLibrary("native-lib");
    }

    private Button button;
    private EditText et;
    private EditText et2;
    private EditText et3;
    private EditText et4;
    private View v;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_name_input);
        //Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        //setSupportActionBar(toolbar);

        button = (Button) findViewById(R.id.nextplayer);
        button.setOnClickListener(this);
        v=(View) findViewById(R.id.vieww);
        v.setOnClickListener(this);


        et = (EditText) findViewById(R.id.editText);
        et2 = (EditText) findViewById(R.id.editText2);
        et3 = (EditText) findViewById(R.id.editText3);
        et4 = (EditText) findViewById(R.id.editText4);



    }

    public void onClick(View v) {
        if (v.getId() == R.id.nextplayer) {

            String text = et.getText().toString();
            String text2 = et2.getText().toString();
            String text3 = et3.getText().toString();
            String text4 = et4.getText().toString();

            setNames(text, text2, text3, text4); //initializing the players' names

            Intent resultActivity = new Intent(nameInput.this, FinalScoreInput.class);
            startActivity(resultActivity);

        } else {
            et.onEditorAction(EditorInfo.IME_ACTION_DONE);
            et2.onEditorAction(EditorInfo.IME_ACTION_DONE);
            et3.onEditorAction(EditorInfo.IME_ACTION_DONE);
            et4.onEditorAction(EditorInfo.IME_ACTION_DONE);
        }
    }

    native void setNames(String text,String text2, String text3, String text4);



    }
