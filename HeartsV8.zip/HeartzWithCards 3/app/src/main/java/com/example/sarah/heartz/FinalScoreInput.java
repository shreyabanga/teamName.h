package com.example.sarah.heartz;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;

public class FinalScoreInput extends AppCompatActivity implements OnClickListener {

    static {
        System.loadLibrary("native-lib");
    }

    private EditText et;
    private View v;
    private Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_final_score_input);


        v = (View) findViewById(R.id.vieww);
        v.setOnClickListener(this);

        button=findViewById(R.id.button) ;
        button.setOnClickListener(this);

        et = (EditText) findViewById(R.id.editText);


    }

    public void onClick(View v) {
        if (v.getId() == R.id.button) {

            String text = et.getText().toString();
            boolean result;

            et.onEditorAction(EditorInfo.IME_ACTION_DONE);

            result=setCapScore(Integer.parseInt(text)); //initializing the cap score names

            if(result==false)
            {Snackbar.make(v, "Enter a positive final score!", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();}
            else
            {

                Intent resultActivity = new Intent(FinalScoreInput.this, player0.class);
                startActivity(resultActivity);
            }



        } else {
            et.onEditorAction(EditorInfo.IME_ACTION_DONE);
        }


    }

    public native boolean setCapScore(int capScore);

}
